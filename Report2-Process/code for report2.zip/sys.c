#include < stdlib.h >

int main()
{
   system( "ls -l /bin" );
   return 0;
}